
sap.ui.define([
    "./BaseController",
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/ui/table/TablePersoController",
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    'sap/ui/model/FilterType',
    "sap/ui/core/Fragment",
    'sap/ui/export/Spreadsheet',
    'sap/ui/export/library',
    "sap/ui/core/BusyIndicator"
], (BaseController, Controller, MessageBox, MessageToast, TablePersoController, Filter, FilterOperator, FilterType, Fragment, Spreadsheet, exportLibrary,BusyIndicator) => {
    "use strict";
    var EdmType = exportLibrary.EdmType;
    return BaseController.extend("com.dhi.cms.cmsrequester.controller.Contracts", {
        onInit() {
            this.getRouter().getRoute("Contracts").attachPatternMatched(this._onObjectMatched, this);

        },
         _onObjectMatched: function (oEvent) {
            this._refreshTable();
            this._setPersonalization();
            this.clearAllFilters();
        },
        onGoBtnPress: function (oEvent) {
            let oFilterbar = this.byId("idFilterBar")
            let aFilterItems = oFilterbar.getAllFilterItems();
            let aFilters = []

            aFilterItems.forEach((aFilterItem) => {
                let sPropertyName = aFilterItem.getName();
                let aSelectedKeys;
                if (sPropertyName === "contract_id") {
                    let sValue = aFilterItem.getControl().getValue();
                    if (sValue) {
                        aFilters.push(new Filter(sPropertyName, "Contains", sValue));
                    }

                }
                else {
                    aSelectedKeys = aFilterItem.getControl().getSelectedKeys();
                    if (aSelectedKeys) {
                        aSelectedKeys.forEach(sValue => {
                            aFilters.push(new Filter(sPropertyName, "EQ", sValue));
                        }
                        )
                    }
                }

            });
            let oTable = this.byId("tblContracts");
            let oBinding = oTable.getBinding("rows");
            oBinding.filter(aFilters);
            this.byId("clearFilters").setEnabled(true);
            MessageToast.show("Filters Applied Sucessfully.")

        },

        onExportData: function (event) {
            let table = this.byId("tblContracts");
            let binding = table.getBinding('rows');
            let columns = this.createColumnConfig();
            let settings = {
                workbook: {
                    columns: columns,
                    hierarchyLevel: 'Level'
                },
                dataSource: binding,
                fileName: 'Contracts.xlsx',
                worker: false 
            };

            let sheet = new Spreadsheet(settings);
            sheet.build().finally(function () {
                sheet.destroy();
            });
        },
        createColumnConfig: function () {
            var columns = [];

            columns.push({
                label: 'ID',
                property: 'ID',
                type: EdmType.String
            });

            columns.push({
                label: 'Contract Name',
                property: 'alias',
                type: EdmType.String
            });

            columns.push({
                label: 'Contract ID',
                property: 'contract_id',
                type: EdmType.String
            });

            columns.push({
                label: 'Description',
                property: 'description',
                type: EdmType.String
            });

            // navigation property for template name
            columns.push({
                label: 'Contract Type',
                property: 'templates/name',
                type: EdmType.String
            });

            columns.push({
                label: 'Start Date',
                property: 'start_date',
                type: EdmType.DateTime
            });

            columns.push({
                label: 'End Date',
                property: 'end_date',
                type: EdmType.DateTime
            });

            return columns;
        },
        _refreshTable: function () {
            this.byId("tblContracts").getBinding("rows").refresh();
        },
       

        onClearFilters: function () {
            this.byId("clearFilters").setEnabled(false);
            this.clearAllFilters();
        },

        clearAllFilters: function () {
            var oTable = this.byId("tblContracts");
            var oFilter = null;
            var aColumns = oTable.getColumns();
            for (var i = 0; i < aColumns.length; i++) {
                oTable.filter(aColumns[i], null);
            }
            this.byId("tblContracts").getBinding("rows").filter(oFilter, "Application");
            this.byId("tblContracts").getBinding("rows").filter([]);
            const oFilterBar = this.byId("idFilterBar");

    if (!oFilterBar) {
        console.warn("FilterBar not found");
        return;
    }
             const aFilterItems = oFilterBar.getFilterGroupItems();

    aFilterItems.forEach(item => {
        const oControl = item.getControl();

        if (!oControl) return;

        // Reset Input
        if (oControl.setValue) {
            oControl.setValue("");
        }

        // Reset MultiComboBox
        if (oControl.setSelectedKeys) {
            oControl.setSelectedKeys([]);
        }

        // Reset DatePicker (if you add one later)
        if (oControl.setDateValue) {
            oControl.setDateValue(null);
        }

        // Reset Checkboxes (if added later)
        if (oControl.setSelected) {
            oControl.setSelected(false);
        }
    });
        },

        onTableFilter: function (oEvent) {
            var sQuery = oEvent.getParameter("value");
            var oTable = this.byId("tblContracts");
            var oBinding = oTable.getBinding("rows");

            if (sQuery) {
                this.byId("clearFilters").setEnabled(true);

                // Get all columns from the table
                var aColumns = oTable.getColumns();
                var aFilters = [];

                // Iterate through each column to create filters
                aColumns.forEach(function (oColumn) {
                    var sFilterProperty = oColumn.getFilterProperty();
                    if (sFilterProperty) {
                        // Create a filter for each column
                        var oFilter = new Filter({
                            path: sFilterProperty,
                            operator: sap.ui.model.FilterOperator.Contains,
                            value1: sQuery,
                            caseSensitive: false
                        });
                        aFilters.push(oFilter);
                    }
                });

                // Combine filters with OR condition
                var oCombinedFilter = new sap.ui.model.Filter({
                    filters: aFilters,
                    and: false
                });

                // Apply the combined filter to the binding
                oBinding.filter(oCombinedFilter, sap.ui.model.FilterType.Application);
                oEvent.preventDefault();

            } else {
                this.byId("clearFilters").setEnabled(false);

                // Clear all filters
                oBinding.filter([], sap.ui.model.FilterType.Application);
            }
        },

        _setPersonalization: function () {
            var oBundle, oDeferred, oPersoService = {
                oPersoData: {
                    _persoSchemaVersion: "1.0",
                    aColumns: []
                },
                getPersData: function () {
                    oDeferred = new jQuery.Deferred();
                    if (!this._oBundle) {
                        this._oBundle = this.oPersoData;
                    }
                    oBundle = this._oBundle;
                    oDeferred.resolve(oBundle);
                    return oDeferred.promise();
                },
                setPersData: function (oBundle) {
                    oDeferred = new jQuery.Deferred();
                    this._oBundle = oBundle;
                    oDeferred.resolve();
                    return oDeferred.promise();
                },
                delPersData: function () {
                    oDeferred = new jQuery.Deferred();
                    oDeferred.resolve();
                    return oDeferred.promise();
                }
            };
            this.oTablePersoController = new TablePersoController({
                table: this.byId("tblContracts"),
                persoService: oPersoService
            });
        },

        onPersonalization: function () {
            // Cause the dialog to open when the button is pressed
            this.oTablePersoController.openDialog();
        },

        onRowsUpdated: function () {
            var oTable = this.byId("tblContracts");
            this.getModel("appModel").setProperty("/ContractCount", oTable.getBinding("rows").getLength());
        },
        onCreateContract: function (sNavigationTarget) {
            var sNavigationTarget;
            if (sNavigationTarget) {
                this.getRouter().navTo(sNavigationTarget);
            } else {
                console.error("Navigation target not defined.");
            }

        },
        onDeleteContract: function (oEvent) {
            const oView = this.getView();
            const oButton = oEvent.getSource();
            const oContext = oButton.getBindingContext(); 
            if (!oContext) {
                sap.m.MessageToast.show("No contract selected for delete.");
                return;
            }
            const sAlias = oContext.getProperty("alias") || oContext.getProperty("contract_id") || "this contract";
            const sConfirmText = `Are you sure you want to delete ${sAlias}?`;
            MessageBox.confirm(sConfirmText, {
                title: "Confirm delete",
                onClose: (sAction) => {
                    if (sAction !== sap.m.MessageBox.Action.OK) {
                        return;
                    }
                    oView.setBusy(true);
                    oContext.delete().then(() => {
                        oView.setBusy(false);
                        MessageToast.show("Contract deleted");
                        const oModel = oView.getModel();
                        try { oModel.refresh(true); } catch (e) {}
                    }).catch((oError) => {
                        oView.setBusy(false);
                        const sMsg = (oError && oError.message) ? oError.message : "Delete failed";
                        MessageBox.error("Failed to delete contract: " + sMsg);
                        try { oView.getModel().refresh(true); } catch (e) { }
                    });
                }
            });
        },
        onEditContract: function (event) {
            let context = event.getSource().getBindingContext();
            let { ID } = context.getObject();
            this.getRouter().navTo("ContractDetails", {
                contractId: ID
            });
             

            
        },
        onViewContract: function (event) {
            let context = event.getSource().getBindingContext();
            let { ID } = context.getObject();
            this.getRouter().navTo("ContractDetails", {
                contractId: ID
            });
           
        },

    });
});