sap.ui.define(["./BaseController","sap/ui/core/Fragment"],(e,n)=>{"use strict";return e.extend("com.dhi.cms.cmsadmin.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map