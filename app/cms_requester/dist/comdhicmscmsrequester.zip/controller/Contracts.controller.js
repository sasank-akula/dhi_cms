sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("com.dhi.cms.cmsrequester.controller.Contracts",{onInit(){}})});
//# sourceMappingURL=Contracts.controller.js.map